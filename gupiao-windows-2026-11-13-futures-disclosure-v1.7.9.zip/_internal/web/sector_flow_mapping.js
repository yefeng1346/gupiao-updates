/* Explicit local reference mappings. No remote quotes, matching guesses or AI. */
(() => {
  let active=null,serial=0,working=false;
  const dialog=$('sectorFlowMappingDialog');
  const query=scope=>new URLSearchParams({provider:scope.provider,sector_type:scope.sector_type,sector_code:scope.sector_code,sector_name:scope.sector_name}).toString();
  const status=text=>{$('sectorFlowMappingStatus').textContent=text;};
  function busy(value){
    working=value;
    for(const id of ['sectorFlowMappingSave','sectorFlowMappingDelete','sectorFlowMappingClose','sectorFlowMappingSearch','sectorFlowMappingTarget','sectorFlowMappingEvidence','sectorFlowMappingConfirmed'])$(id).disabled=value;
  }
  function choices(){
    const old=$('sectorFlowMappingTarget').value;
    const term=$('sectorFlowMappingSearch').value.trim().toLowerCase();
    const targets=(active?.data?.targets||[]).filter(r=>`${r.sector_code} ${r.sector_name}`.toLowerCase().includes(term));
    $('sectorFlowMappingTarget').innerHTML='<option value="">请选择经核对的目标，不会自动配对</option>'+targets.map(r=>`<option value="${esc(r.sector_code)}">${esc(r.sector_name)} · ${esc(r.sector_code)}</option>`).join('');
    $('sectorFlowMappingTarget').value=targets.some(r=>r.sector_code===old)?old:'';
  }
  async function open(scope){
    if(working)return;
    const token=++serial;active={scope,data:null};
    $('sectorFlowMappingSource').textContent=`原来源 ${scope.provider} · ${scope.sector_type==='industry'?'行业':'概念'} · ${scope.sector_name} ${scope.sector_code}`;
    $('sectorFlowMappingSearch').value='';$('sectorFlowMappingEvidence').value='';$('sectorFlowMappingConfirmed').checked=false;
    $('sectorFlowMappingTarget').innerHTML='<option value="">正在读取本地目录</option>';
    $('sectorFlowMappingDelete').hidden=true;busy(true);status('正在读取本地目录和已保存对应，不下载行情…');
    dialog.showModal();
    try{
      const data=await api(`/api/sector-flow-mapping?${query(scope)}`);
      if(token!==serial)return;
      active.data=data;$('sectorFlowMappingNote').textContent=data.note;choices();
      if(data.mapping){
        $('sectorFlowMappingTarget').value=data.mapping.target_code;
        $('sectorFlowMappingEvidence').value=data.mapping.evidence;
        $('sectorFlowMappingDelete').hidden=false;
      }
      status(data.targets.length?'请选择目标并实际核对后保存；仅仅名字相似不能确认。':'本地东方财富目录为空，请先更新资金数据并重新打开此窗口。');
    }catch(error){if(token===serial)status(`读取失败：${error.message}；未修改任何对应。`);}
    finally{if(token===serial)busy(false);}
  }
  document.addEventListener('click',event=>{
    const button=event.target?.closest?.('[data-flow-map]');
    if(!button)return;
    event.preventDefault();event.stopPropagation();
    void open({provider:button.dataset.provider,sector_type:button.dataset.sectorType,sector_code:button.dataset.sectorCode,
               sector_name:button.dataset.sectorName,report_date:button.dataset.reportDate});
  });
  $('sectorFlowMappingSearch').oninput=choices;
  $('sectorFlowMappingClose').onclick=()=>{if(!working){++serial;active=null;dialog.close();}};
  dialog.addEventListener('cancel',event=>{if(working)event.preventDefault();else{++serial;active=null;}});
  $('sectorFlowMappingSave').onclick=async()=>{
    if(working||!active?.data)return;
    const current=active,scope=current.scope;
    const target=current.data.targets.find(r=>r.sector_code===$('sectorFlowMappingTarget').value);
    const evidence=$('sectorFlowMappingEvidence').value.trim();
    if(!target){status('请选择本地东方财富目录中的目标板块。');return;}
    if(!$('sectorFlowMappingConfirmed').checked||evidence.length<8){status('请实际核对名称含义和成分范围、填写至少8字核对说明，并勾选人工核对确认。');return;}
    if(!confirm(`保存参考对应？\n${scope.sector_name} ${scope.sector_code} → ${target.sector_name} ${target.sector_code}\n这不是相同板块认证，资金仅作东方财富对应板块参考。`))return;
    busy(true);
    try{
      const {report_date,...identity}=scope;
      const result=await api('/api/sector-flow-mapping',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({...identity,target_code:target.sector_code,target_name:target.sector_name,confirmed:true,evidence})});
      current.data.mapping=result.mapping;$('sectorFlowMappingDelete').hidden=false;
      status('已保存人工核对的参考对应，正在重算原日期本地资金列…');
      try{await refreshSectorFlowMapping(scope);status('已保存并重算原日期资金列；排名不变，缺少三日数据时仍显示不足。');}
      catch(error){status(`对应已保存；本地报告刷新失败：${error.message}。请手动重新读取报告。`);}
    }catch(error){status(`保存失败：${error.message}；原对应、原报告和填写内容保留。`);}
    finally{busy(false);}
  };
  $('sectorFlowMappingDelete').onclick=async()=>{
    if(working||!active?.data?.mapping)return;
    const current=active,scope=current.scope;
    if(!confirm(`取消 ${scope.sector_name} ${scope.sector_code} 这一条参考对应？\n保留资金历史、其他板块对应及候选名单。`))return;
    busy(true);
    try{
      await api(`/api/sector-flow-mapping?${query(scope)}`,{method:'DELETE'});
      current.data.mapping=null;$('sectorFlowMappingDelete').hidden=true;
      $('sectorFlowMappingConfirmed').checked=false;
      try{await refreshSectorFlowMapping(scope);status('已取消这一条对应，恢复代码／唯一同名规则；未删除资金档案。');}
      catch(error){status(`对应已取消；请重新读取报告：${error.message}`);}
    }catch(error){status(`取消失败：${error.message}；原对应和报告保留。`);}
    finally{busy(false);}
  };
})();
