/* Local cache on open; network refresh only after the user's explicit click. */
(() => {
  let busy=false,generation=0;
  const sources=['auto','eastmoney','sina'];
  try{const saved=localStorage.getItem('gupiao.etfNavSource');if(sources.includes(saved))$('etfFlowSource').value=saved;}catch{}
  const source=()=>sources.includes($('etfFlowSource').value)?$('etfFlowSource').value:'auto';
  const share=value=>value==null?'缺失':`${value>=0?'+':''}${(value/1e8).toFixed(2)}`;
  const amount=value=>value==null?'缺失':flowAmount(value);
  function rule() {
    const windowDays=Number($('etfFlowWindowDays').value),minDays=Number($('etfFlowMinInflowDays').value);
    if(!Number.isInteger(windowDays)||windowDays<1||windowDays>60)throw new Error('ETF统计天数请填写1～60个交易日');
    if(!Number.isInteger(minDays)||minDays<1||minDays>windowDays)throw new Error('ETF至少流入天数必须在1～统计天数之间');
    return {windowDays,minDays};
  }
  function screening(data) {
    const s=data.inflow_days_rank;
    if(!s)return '';
    return `<div class="capital-flow-rank-card"><h4>${s.window_days}天内至少${s.min_inflow_days}天资金流入榜（ETF）</h4><p class="muted">仅纳入最近${s.window_days}个交易日份额及净值完整、日估算净申购额大于0至少${s.min_inflow_days}天的ETF，按流入天数及区间累计额排序。不是二级市场主力资金流向。</p><p class="${s.complete?'muted':'notice'}">完整区间 ${s.eligible}/${s.total}只；沪市 ${s.markets.SH.complete}/${s.markets.SH.total}，深市 ${s.markets.SZ.complete}/${s.markets.SZ.total}；数据不足 ${s.missing_count}只，分红／拆分等需复核 ${s.event_excluded}只；符合条件 ${s.matched}只。缺失不补零，不用更早日期凑数。</p>${s.missing_examples?.length?`<details><summary>查看数据不足示例</summary><p class="muted">${s.missing_examples.map(r=>`${esc(r.name)} ${esc(r.code)}：${r.available_days}/${s.window_days}天`).join('；')}（仅部分，不参与筛选）</p></details>`:''}<div class="capital-flow-table capital-flow-table-scroll etf-rank-table"><table><thead><tr><th>排名</th><th>证券代码／基金简称</th><th>流入天数</th><th>${s.window_days}日累计估算净申购额</th></tr></thead><tbody>${s.rows.length?s.rows.map((r,i)=>`<tr><td>${i+1}</td><td><b>${esc(r.name)}</b><small>${esc(r.code)}</small></td><td><b>${r.inflow_days}/${s.window_days}天</b></td><td>${flowAmount(r.net_inflow)}</td></tr>`).join(''):`<tr><td colspan="4" class="muted">${s.complete?'完整数据中暂无符合条件的ETF。':'暂无符合条件的ETF；数据不足或需复核的ETF未参与判断，请更新／继续补缺。'}</td></tr>`}</tbody></table></div></div>`;
  }
  function render(data) {
    $('etfFlowSourceInfo').textContent=`净值来源：${data.source_label||source()}；${data.source_note||'份额仍取交易所，仅切换同日期单位净值。'} 实际已保存净值：${(data.nav_sources||[]).join('／')||'尚无'}。`;
    const ranks=(rows,title)=>`<div class="capital-flow-rank-card"><h4>${title}</h4><div class="capital-flow-table capital-flow-table-scroll etf-rank-table"><table><thead><tr><th>排名</th><th>证券代码／基金简称</th><th>份额变化（亿份）</th><th>成交额</th><th>估算净流入额</th></tr></thead><tbody>${rows.length?rows.map((row,i)=>`<tr><td>${i+1}</td><td><b>${esc(row.name)}</b><small>${esc(row.code)}</small></td><td>${share(row.share_change)}</td><td>${amount(row.amount)}</td><td>${flowAmount(row.net_inflow)}</td></tr>`).join(''):'<tr><td colspan="5" class="muted">暂无有效记录；数据不足不等于没有资金流入／流出。</td></tr>'}</tbody></table></div></div>`;
    $('etfFlowResults').innerHTML=`<p><b>数据截至 ${esc(data.cutoff)}</b> · ${data.days===1?'日':'近5个交易日'} · ${esc(data.dates?.[0]||'—')} 至 ${esc(data.cutoff)}</p><p class="muted">${esc(data.method)}</p><p class="${data.complete?'muted':'notice'}">${data.complete?'当前名单区间覆盖完整':'区间尚未完整，以下仅为已完成数据的样本排名'}：沪市 ${data.markets.SH.complete}/${data.markets.SH.total}，深市 ${data.markets.SZ.complete}/${data.markets.SZ.total}；缺失 ${data.missing_count}，分红／拆分等需复核 ${data.event_excluded}。${data.stale?'正在显示旧记录，不是最新交易日数据。':''}</p><p class="muted">${esc(data.note)} 成交额缺失显示“缺失”，不影响已有净申购估算记录的保存。</p><div class="capital-flow-rank-grid">${ranks(data.inflow,'估算净流入榜')}${ranks(data.outflow,'估算净流出榜')}</div>${screening(data)}`;
  }
  async function load() {
    const {windowDays,minDays}=rule(),token=++generation;
    const data=await api(`/api/etf-flow?days=${Number($('etfFlowDays').value)}&limit=${Number($('etfFlowLimit').value)}&window_days=${windowDays}&min_inflow_days=${minDays}&source=${source()}`);
    if(token===generation)render(data);
  }
  async function poll(job) {
    busy=true;$('etfFlowRefresh').disabled=true;
    if(job?.source)$('etfFlowSource').value=job.source;
    $('etfFlowSource').disabled=true;
    $('etfFlowWindowDays').disabled=true;$('etfFlowMinInflowDays').disabled=true;
    try {
      while(job?.status==='running') {
        $('etfFlowStatus').textContent=`${job.message}；按${job.window_days||10}个交易日补缺；进度 ${job.attempted}/${job.total}，成功处理 ${job.succeeded}，异常 ${job.failed}`;
        await load();
        await new Promise(resolve=>setTimeout(resolve,1500));
        job=(await api('/api/etf-flow/status')).job;
      }
      $('etfFlowStatus').textContent=job?.message||'已恢复本机ETF记录。';
      await load();
    } finally {busy=false;$('etfFlowRefresh').disabled=false;$('etfFlowWindowDays').disabled=false;$('etfFlowMinInflowDays').disabled=false;$('etfFlowSource').disabled=false;}
  }
  $('etfFlowRefresh').onclick=async()=>{
    if(busy)return;
    busy=true;$('etfFlowRefresh').disabled=true;
    try {const {windowDays}=rule();await poll((await api(`/api/etf-flow/refresh?window_days=${windowDays}&source=${source()}`,{method:'POST'})).job);}
    catch(error){$('etfFlowStatus').textContent=`更新未完成，已显示及已保存记录保留：${error.message}`;}
    finally {busy=false;$('etfFlowRefresh').disabled=false;}
  };
  $('etfFlowSource').onchange=()=>{
    try{localStorage.setItem('gupiao.etfNavSource',source());}catch{}
    void load().then(()=>{$('etfFlowStatus').textContent='已切换本机净值记录；若数据不足，请点“更新沪深ETF数据／继续补缺”。切换本身不联网。';}).catch(error=>{$('etfFlowStatus').textContent=error.message;});
  };
  for(const id of ['etfFlowDays','etfFlowLimit']) $(id).onchange=()=>void load().catch(error=>{$('etfFlowStatus').textContent=error.message;});
  for(const id of ['etfFlowWindowDays','etfFlowMinInflowDays']) $(id).onchange=()=>{
    const n=Number($('etfFlowWindowDays').value);
    if(Number.isInteger(n)&&n>=1&&n<=60){$('etfFlowMinInflowDays').max=n;if(Number($('etfFlowMinInflowDays').value)>n)$('etfFlowMinInflowDays').value=n;}
    void load().catch(error=>{$('etfFlowStatus').textContent=error.message;});
  };
  void (async()=>{try {await load();const job=(await api('/api/etf-flow/status')).job;if(job?.status==='running'){if(job.window_days){$('etfFlowWindowDays').value=job.window_days;$('etfFlowMinInflowDays').max=job.window_days;if(Number($('etfFlowMinInflowDays').value)>job.window_days)$('etfFlowMinInflowDays').value=job.window_days;}await poll(job);}}catch(error){$('etfFlowStatus').textContent=`本地ETF记录恢复失败：${error.message}`;}})();
})();
