/* Local reads on open/date changes; only the explicit refresh button starts a job. */
(() => {
  const dateInput = $('futuresDate'), loadButton = $('futuresLoad');
  const refreshButton = $('futuresRefresh'), status = $('futuresStatus');
  const results = $('futuresResults'), chooser = $('futuresMembers');
  const saveButton = $('futuresSaveMembers');
  if (![dateInput, loadButton, refreshButton, status, results, chooser, saveButton].every(Boolean)) return;

  const products = ['IM', 'IC', 'IF', 'IH'];
  const controls = [dateInput, loadButton, refreshButton, saveButton];
  let busy = false, generation = 0, membersDirty = false, savedSelection = null;
  const text = value => esc(String(value ?? ''));
  const boxes = () => Array.from(chooser.querySelectorAll('input[type="checkbox"]'));
  const selected = () => boxes().filter(box => box.checked).map(box => box.value);
  const sameMembers = (a, b) => a.length === b.length && a.every(name => b.includes(name));
  const signed = value => `${value > 0 ? '+' : ''}${value}`;

  function setBusy(value) {
    busy = value;
    for (const control of [...controls, ...boxes()]) control.disabled = value;
  }

  function cell(row, key) {
    const value = row?.[key];
    if (!row || row.complete !== true || typeof value !== 'number' || !Number.isFinite(value)) {
      return `<span title="${text(row?.reason || '公布排名覆盖不完整，缺失不补零')}">${row?.published === false ? '未公布' : '缺失'}</span>`;
    }
    if (key === 'net_short') return `<span title="净空值 ${signed(value)}手">${value < 0 ? '净多' : '净空'}${Math.abs(value)}手</span>`;
    return key === 'change' ? signed(value) : text(value);
  }

  function coverage(row) {
    if (row?.disclosed) {
      return ['long','short'].map(side => {
        const value=row.disclosed[side], label=side==='long'?'多单':'空单';
        return `<span>${label} ${text(value.covered)}/${text(value.expected)}${value.unknown_scopes?`，另${text(value.unknown_scopes)}处范围未知`:''}</span>`;
      }).join('<br>');
    }
    return `${text(row?.covered ?? '未知')}/${text(row?.expected ?? '未知')}`;
  }

  function sideCell(row, side) {
    const value=row?.disclosed?.[side];
    if (!value) return cell(row,side); // Older local API response compatibility.
    const known=value.covered>0 && typeof value.value==='number' && Number.isFinite(value.value);
    const full=value.complete===true && value.unknown_scopes===0 && value.covered===value.expected;
    return `${known?`${text(value.value)}手`:'暂无公布值'}<small>${known?(full?'已公布完整':'已公布部分'):'未公布，不按0处理'}</small>`;
  }

  function missingDetails(row) {
    if (!row?.disclosed) return '';
    const missing=['long','short'].flatMap(side=>row.disclosed[side].missing||[]);
    if (!missing.length) return '';
    return `<details class="futures-missing-details"><summary>缺失明细（${missing.length}项）</summary><ul class="futures-missing-list">${missing.map(item=>`<li>${text(item.reason)}</li>`).join('')}</ul></details>`;
  }

  function netCell(row, key) {
    if (row?.disclosed && row.complete!==true) return `<span title="${text(row.reason||'两侧公布范围不完整，不能用部分合计相减')}">暂不可计算</span>`;
    return cell(row,key);
  }

  function table(title, headers, rows) {
    return `<section><h4>${text(title)}</h4><div class="capital-flow-table capital-flow-table-scroll futures-table" style="max-height:360px;overflow:auto"><table><thead><tr>${headers.map(h => `<th scope="col">${text(h)}</th>`).join('')}</tr></thead><tbody>${rows.length ? rows.join('') : `<tr><td colspan="${headers.length}">尚无本机记录；未公布或缺失不等于零持仓。</td></tr>`}</tbody></table></div></section>`;
  }

  function positionRow(label, row) {
    return `<tr><th scope="row">${text(label)}</th><td>${sideCell(row, 'long')}</td><td>${sideCell(row, 'short')}</td><td>${netCell(row, 'net_short')}</td><td>${netCell(row, 'change')}</td><td>${coverage(row)}${missingDetails(row)}</td></tr>`;
  }

  function matrix(title, rows) {
    return table(title, ['合约月份', ...products, '已公布合约合计', '合计净空变化'], (rows || []).map(row =>
      `<tr><th scope="row">${text(row.month)}</th>${products.map(product => `<td>${cell(row[product], 'net_short')}<small>净空变化 ${cell(row[product], 'change')}</small></td>`).join('')}<td>${cell(row.total, 'net_short')}</td><td>${cell(row.total, 'change')}</td></tr>`));
  }

  function sources(data) {
    return `<details><summary>来源与采集记录</summary>${(data.sources || []).map(source => {
      const url = String(source.source_url ?? '');
      // Do not turn arbitrary report metadata into navigable links.
      const link = /^https?:\/\/www\.cffex\.com\.cn\/sj\/ccpm\//.test(url)
        ? `<a href="${text(url)}" target="_blank" rel="noopener noreferrer">${text(url)}</a>`
        : `${text(url)}（非允许的中金所来源链接）`;
      return `<p>${text(source.product)} · 公布日期 ${text(source.trade_date)} · 采集时间 ${text(source.captured_at)}<br>${link}<br>SHA256 ${text(source.sha256)}</p>`;
    }).join('') || '<p>尚无本机来源记录。</p>'}</details>`;
  }

  function renderMembers(data) {
    const focus = data.focus?.member || '中信期货(代客)';
    const saved = (data.other_members || []).filter(name => name !== focus);
    const available = new Set((data.available_members || []).filter(name => name !== focus));
    const checked = selected();
    // Read actual DOM state as well as change events, preserving edits across local reloads.
    const edited = membersDirty || (savedSelection !== null && !sameMembers(checked, savedSelection));
    const chosen = new Set(edited ? checked : saved);
    const names = [...new Set([...saved, ...available, ...(edited ? checked : [])])].filter(name => name !== focus);
    chooser.replaceChildren();
    for (const name of names) {
      const label = document.createElement('label');
      const input = document.createElement('input');
      input.type = 'checkbox'; input.value = name; input.checked = chosen.has(name); input.disabled = busy;
      const caption = document.createElement('span');
      caption.textContent = name + (!available.has(name) ? '（本日未公布／未出现，保留原始已保存名称）' : '');
      label.append(input, caption); chooser.appendChild(label);
    }
    if (!names.length) chooser.textContent = '尚无可选原始会员名；请先显式更新数据。';
    savedSelection = saved;
    membersDirty = edited;
  }

  function render(data) {
    const focus = data.focus?.member || '中信期货(代客)';
    const headers = ['品种', '已公布多单', '已公布空单', '完整净空（负数净多）', '完整净空变化', '多／空覆盖'];
    const aggregates = table(`${focus} · 品种汇总（手）`, headers,
      (data.product_rows || []).map(row => positionRow(`${row.product} ${row.label || ''}`, row)));
    const memberRows = (data.members || []).map(row => positionRow(row.member, row));
    memberRows.push(positionRow('其他所选会员合计', data.others), positionRow('两组合计', data.combined));
    const comparison = table('所选会员对照（原始名称，手）', ['会员', ...headers.slice(1)], memberRows);
    const html = `<p>请求日期 ${text(data.requested_date)} · 目标交易日 ${text(data.target_date)} · 实际数据日期 ${text(data.trade_date || '尚无本机记录')}</p>
      <p class="${data.complete ? 'muted' : 'notice'}">${data.complete ? '覆盖完整' : '覆盖不完整；缺失不补零'}${data.stale ? '；当前显示旧记录，不是目标交易日数据' : ''}。缺失品种：${text((data.missing_products || []).join('、') || '无')}。已保存日期：${text((data.saved_dates || []).join('、') || '无')}</p>
      ${data.http_warning ? '<p class="notice">HTTP 非加密通道警告：部分来源通过未加密 HTTP 获取，传输存在被篡改风险，请核对原始来源与采集记录。</p>' : ''}
      <p class="muted">净空 = 空单 − 多单；正数净空、负数净多。净空变化 = 空单增减 − 多单增减；变化不代表实际空单的增减。</p>
      <p class="muted">多单和空单分别显示已公布合计及覆盖：项数按“会员×合约”统计，部分数据明确标记，不能当作完整持仓或直接相减。品种文件未取得时范围未知，单列提示，不冒充100%覆盖。展开“缺失明细”可查具体合约、会员及方向；未上榜不等于0，反复刷新不能补出未公布数据。</p>
      <p class="muted">矩阵按已公布合约合计；未公布合约不视为零。合计沿用后端公布范围，会员任一侧缺失时不补零、不伪造分组合计。</p>
      <p class="muted">${text(data.note)}</p>${aggregates}${comparison}
      ${matrix(`${focus} · 月份×品种（手）`, data.focus_matrix)}${matrix('其他所选会员 · 月份×品种（手）', data.other_matrix)}
      <section><h4>每日生成摘要</h4><p>${text(data.summary)}</p></section>${sources(data)}`;
    // Build before replacing anything: failed requests keep the last successful report.
    renderMembers(data);
    results.innerHTML = html;
  }

  async function load({ date = dateInput.value, quiet = false, propagate = false } = {}) {
    const token = ++generation;
    try {
      const data = await api(`/api/futures-positions?trade_date=${encodeURIComponent(date)}`);
      if (token !== generation || date !== dateInput.value) return false;
      render(data);
      if (!quiet && !busy) status.textContent = '已读取本机期指记录；查询与分组切换不访问外部网络。';
      return true;
    } catch (error) {
      if (token !== generation || date !== dateInput.value) return false;
      if (propagate) throw error;
      status.textContent = `本机记录读取失败，原结果保留：${error.message}`;
      return false;
    }
  }

  function showJob(job) {
    status.textContent = `更新任务实际日期 ${job.trade_date || '未知'} · ${job.status || '未知'} · ${job.message || ''}；已尝试 ${job.attempted ?? '未知'}/4，成功 ${job.succeeded ?? '未知'}，异常 ${job.failed ?? '未知'}${job.errors?.length ? `；${job.errors.join('；')}` : ''}。`;
  }

  async function poll(job, date) {
    if (!job) throw new Error('更新任务状态缺失，已有记录保留');
    while (job.status === 'running' || job.status === 'pending' || job.status === 'queued') {
      showJob(job);
      await new Promise(resolve => setTimeout(resolve, 1500));
      job = (await api('/api/futures-positions/status')).job;
      if (!job) throw new Error('更新任务状态缺失，已有记录保留');
    }
    showJob(job);
    // The singleton may belong to another window/date. Never retarget the user's query.
    await load({ date, quiet: true, propagate: true });
  }

  loadButton.onclick = dateInput.onchange = () => busy ? undefined : load();
  chooser.onchange = () => { membersDirty = true; };

  saveButton.onclick = async () => {
    if (busy) return;
    const members = selected();
    if (members.length < 1 || members.length > 20) {
      status.textContent = '请选择1～20个其他会员，按原始名称保存。'; return;
    }
    const date = dateInput.value;
    ++generation; setBusy(true);
    try {
      await api('/api/futures-positions/settings', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ members })
      });
      membersDirty = false; savedSelection = members;
      await load({ date, quiet: true, propagate: true });
      status.textContent = '其他会员分组已保存，并重新读取本机记录；没有发起外部更新。';
    } catch (error) {
      status.textContent = `分组保存／读取未完成，原结果与选择保留：${error.message}`;
    } finally { setBusy(false); }
  };

  refreshButton.onclick = async () => {
    if (busy) return;
    const date = dateInput.value;
    ++generation; setBusy(true);
    try {
      const response = await api(`/api/futures-positions/refresh?trade_date=${encodeURIComponent(date)}`, { method: 'POST' });
      await poll(response.job, date);
    } catch (error) {
      status.textContent = `更新未完成，原结果及已保存记录保留：${error.message}`;
    } finally { setBusy(false); }
  };

  void load();
  const initialToken = generation;
  void (async () => {
    let following = false;
    try {
      const { job } = await api('/api/futures-positions/status');
      if (initialToken !== generation || busy || job?.status !== 'running') return;
      following = true;
      setBusy(true);
      try { await poll(job, dateInput.value); }
      finally { setBusy(false); }
    } catch (error) {
      if (following || (initialToken === generation && !busy)) {
        status.textContent = `本机更新状态读取失败，原结果保留：${error.message}`;
      }
    }
  })();
})();
