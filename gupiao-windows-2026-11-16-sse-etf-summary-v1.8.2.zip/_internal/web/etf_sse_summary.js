/* Text only; restore/source changes read local cache, explicit refresh fetches. */
(()=>{
  const sourceInput=$('sseSummarySource'),button=$('sseSummaryRefresh'),status=$('sseSummaryStatus'),results=$('sseSummaryResults');
  if(!sourceInput||!button||!status||!results)return;
  let busy=false,generation=0;
  const source=()=>['auto','eastmoney','sina'].includes(sourceInput.value)?sourceInput.value:'auto';
  const text=v=>esc(String(v??''));
  const money=value=>{
    if(typeof value!=='number'||!Number.isFinite(value))return '暂不可计算';
    const size=Math.abs(value)/1e8,label=value<0?'净赎回':value>0?'净申购':'无净变化';
    return label+(size>0&&size<.005?'不足0.01亿元':`${size.toFixed(2)}亿元`);
  };
  function render(data){
    results.innerHTML=`<h3>上交所ETF近20个交易日净申赎额（估算）</h3><p>统计区间 ${text(data.start_date)} 至 ${text(data.cutoff)}；基准日 ${text(data.baseline_date)}；净值来源 ${text(data.source_label)}。${data.stale?'当前为旧记录，不是最新目标交易日数据。':''}</p><p class="${data.complete?'muted':'notice'}">完整 ${text(data.complete_days)}/20个交易日；${data.complete?`区间合计：${money(data.net_subscription)}`:'区间合计暂不可计算，不把已完成的部分相加冒充20日全市场数据'}。已完整日期中：净申购${text(data.positive_days)}日、净赎回${text(data.negative_days)}日、无净变化${text(data.zero_days)}日。</p><details><summary>逐日文字统计（点击查看）</summary><ul style="max-height:280px;overflow:auto">${(data.daily||[]).map(r=>`<li>${text(r.trade_date)}：${r.complete?money(r.net_subscription):'暂不可计算'}；覆盖${text(r.eligible)}/${text(r.total)}只${r.reason?`；${text(r.reason)}`:''}。</li>`).join('')}</ul></details><details><summary>计算口径与数据说明</summary><p class="muted">${text(data.method)} ${text(data.note)}</p></details>`;
  }
  async function load(){
    const token=++generation,s=source();const data=await api(`/api/etf-sse-summary?source=${s}`);
    if(token===generation&&s===source())render(data);
  }
  function setBusy(value){busy=value;button.disabled=value;sourceInput.disabled=value;}
  async function poll(job){
    if(!job)throw Error('更新状态缺失，已有数据保留');
    if(job.source)sourceInput.value=job.source;
    while(job.status==='running'){
      status.textContent=`${job.message}；本轮${job.attempted}/${job.total}，成功${job.succeeded}，异常${job.failed}`;
      await load();await new Promise(r=>setTimeout(r,1500));job=(await api('/api/etf-sse-summary/status')).job;
      if(!job)throw Error('更新状态缺失，已有数据保留');
    }
    await load();status.textContent=job.message||'已读取本机记录。';
  }
  button.onclick=async()=>{
    if(busy)return;++generation;setBusy(true);
    try{await poll((await api(`/api/etf-sse-summary/refresh?source=${source()}`,{method:'POST'})).job);}
    catch(error){status.textContent=`更新未完成，原结果及记录保留：${error.message}`;}
    finally{setBusy(false);}
  };
  sourceInput.onchange=()=>{if(busy)return;void load().then(()=>status.textContent='已切换本机净值记录；数据不足可点击继续补缺，切换本身不联网。').catch(error=>status.textContent=error.message);};
  void(async()=>{
    try{await load();if(busy)return;const token=generation,job=(await api('/api/etf-sse-summary/status')).job;
      if(token!==generation||busy||job?.status!=='running')return;
      setBusy(true);try{await poll(job);}finally{setBusy(false);}
    }catch(error){if(!busy)status.textContent=`本机统计恢复未完成，原结果保留：${error.message}`;}
  })();
})();
