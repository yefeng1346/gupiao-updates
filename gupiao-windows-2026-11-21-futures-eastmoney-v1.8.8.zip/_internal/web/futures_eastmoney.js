/* This panel never refreshes the CFFEX report or fetches on page open. */
(() => {
  const member = $('eastmoneyFuturesMember'), date = $('eastmoneyFuturesDate');
  const refresh = $('eastmoneyFuturesRefresh'), status = $('eastmoneyFuturesStatus');
  const result = $('eastmoneyFuturesResult');
  if (![member,date,refresh,status,result].every(Boolean)) return;
  let generation = 0;
  const number = value => new Intl.NumberFormat('zh-CN').format(Math.abs(value));
  const signed = value => (value < 0 ? '−' : value > 0 ? '+' : '') + number(value);

  function describe(before, after, change) {
    if (change === 0) return '净持仓无变化';
    if (before <= 0 && after <= 0) return `净空${change > 0 ? '减少' : '增加'} ${number(change)} 手`;
    if (before >= 0 && after >= 0) return `净多${change > 0 ? '增加' : '减少'} ${number(change)} 手`;
    return `由${before < 0 ? '净空转净多' : '净多转净空'}，净持仓变化 ${signed(change)} 手`;
  }

  function render(data) {
    const dayRow = (day, row) => {
      const complete = Number.isInteger(row.net);
      const scope = Number.isInteger(row.expected) ? `${row.covered}/${row.expected}` : '基准范围未取得';
      const missing = row.missing.length ? `<small class="muted">未披露或缺记录：${esc(row.missing.join('、'))}</small>` : '';
      return `<tr><td>${esc(day)}</td><td>${complete ? signed(row.net)+' 手' : '暂不合计'}</td><td>${esc(scope)}${missing}</td></tr>`;
    };
    const summary = Number.isInteger(data.change) ? describe(data.previous.net,data.current.net,data.change)
      : data.scope_changed ? '两日合约范围不同，暂不比较。' : '两日数据未齐，暂不比较。';
    result.innerHTML = `<p class="futures-em-summary">${esc(data.member_name)} · ${esc(summary)}</p>
      <div class="capital-flow-table"><table><thead><tr><th scope="col">交易日</th><th scope="col">净持仓</th><th scope="col">覆盖（合约）</th></tr></thead>
      <tbody>${dayRow(data.trade_date,data.current)}${dayRow(data.previous_date,data.previous)}</tbody></table></div>`;
  }

  async function load(update=false) {
    const token = ++generation;
    const query = `?member=${encodeURIComponent(member.value)}&trade_date=${encodeURIComponent(date.value)}`;
    if (!update) result.innerHTML = '';
    if (update) member.disabled = date.disabled = refresh.disabled = true;
    status.textContent = update ? '正在读取东财两日持仓…' : '正在读取本机东财记录…';
    try {
      const data = update ? await api('/api/futures-eastmoney/refresh'+query,{method:'POST'})
                          : await api('/api/futures-eastmoney'+query);
      if (token !== generation) return;
      render(data);
      status.textContent = update ? '已更新并保存东财记录。' : '仅查看本机记录；点击更新可向东财取数。';
    } catch (error) {
      if (token === generation) status.textContent = `${update ? '更新未完成，已保留原记录' : '本机记录读取失败'}：${error.message}`;
    } finally {
      if (update) member.disabled = date.disabled = refresh.disabled = false;
    }
  }

  member.onchange = date.onchange = () => load();
  refresh.onclick = () => refresh.disabled ? undefined : load(true);
  void load();
})();
