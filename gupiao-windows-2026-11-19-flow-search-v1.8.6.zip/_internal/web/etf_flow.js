/* Local cache on open; network refresh only after the user's explicit click. */
(() => {
  let busy=false,generation=0,shownWeek=null;
  const chinaOffset=8*60*60*1000,weekMs=7*24*60*60*1000;
  const mondayStamp=()=>{
    const day=new Date(Date.now()+chinaOffset);
    return Date.UTC(day.getUTCFullYear(),day.getUTCMonth(),day.getUTCDate()-(day.getUTCDay()+6)%7);
  };
  const localWeek=()=>new Date(mondayStamp()).toISOString().slice(0,10);
  const weekPlaceholder=message=>`<h5>本周小结</h5><p class="etf-broad-week-status">${message}</p>`;
  const sources=['auto','eastmoney','sina'];
  try{const saved=localStorage.getItem('gupiao.etfNavSource');if(sources.includes(saved))$('etfFlowSource').value=saved;}catch{}
  const source=()=>sources.includes($('etfFlowSource').value)?$('etfFlowSource').value:'auto';
  const share=value=>value==null?'缺失':`${value>=0?'+':''}${(value/1e8).toFixed(2)}`;
  const amount=value=>value==null?'缺失':flowAmount(value);
  function rule() {
    const windowDays=Number($('etfFlowWindowDays').value),minDays=Number($('etfFlowMinInflowDays').value);
    if(!Number.isInteger(windowDays)||windowDays<1||windowDays>60)throw new Error('ETF统计天数请填写1～60个交易日');
    if(!Number.isInteger(minDays)||minDays<1||minDays>windowDays)throw new Error('ETF至少流入天数必须在1～统计天数之间');
    return {windowDays,minDays};
  }
  function screening(data) {
    const s=data.inflow_days_rank;
    if(!s)return '';
    return `<div class="capital-flow-rank-card"><h4>${s.window_days}天内至少${s.min_inflow_days}天资金流入榜（ETF）</h4><p class="muted">仅纳入最近${s.window_days}个交易日份额及净值完整、日估算净申购额大于0至少${s.min_inflow_days}天的ETF，按流入天数及区间累计额排序。不是二级市场主力资金流向。</p><p class="${s.complete?'muted':'notice'}">完整区间 ${s.eligible}/${s.total}只；沪市 ${s.markets.SH.complete}/${s.markets.SH.total}，深市 ${s.markets.SZ.complete}/${s.markets.SZ.total}；数据不足 ${s.missing_count}只，分红／拆分等需复核 ${s.event_excluded}只；符合条件 ${s.matched}只。缺失不补零，不用更早日期凑数。</p>${s.missing_examples?.length?`<details><summary>查看数据不足示例</summary><p class="muted">${s.missing_examples.map(r=>`${esc(r.name)} ${esc(r.code)}：${r.available_days}/${s.window_days}天`).join('；')}（仅部分，不参与筛选）</p></details>`:''}<div class="capital-flow-table capital-flow-table-scroll etf-rank-table"><table><thead><tr><th>排名</th><th>证券代码／基金简称</th><th>流入天数</th><th>${s.window_days}日累计估算净申购额</th></tr></thead><tbody>${s.rows.length?s.rows.map((r,i)=>`<tr><td>${i+1}</td><td><b>${esc(r.name)}</b><small>${esc(r.code)}</small></td><td><b>${r.inflow_days}/${s.window_days}天</b></td><td>${flowAmount(r.net_inflow)}</td></tr>`).join(''):`<tr><td colspan="4" class="muted">${s.complete?'完整数据中暂无符合条件的ETF。':'暂无符合条件的ETF；数据不足或需复核的ETF未参与判断，请更新／继续补缺。'}</td></tr>`}</tbody></table></div></div>`;
  }
  function broadIndexSummary(data) {
    const broad=data.broad_index_summary;
    if(!broad?.rows?.length)return '';
    const usable=r=>typeof r.net_subscription==='number'&&Number.isFinite(r.net_subscription);
    const amountText=value=>{
      if(typeof value!=='number'||!Number.isFinite(value))return '—';
      const units=Math.abs(value)/1e8;
      const sign=value<0?'-':value>0?'+':'';
      return units>0&&units<.005?`${sign}&lt;0.01 亿元`:`${sign}${units.toFixed(2)} 亿元`;
    };
    const coverage=r=>`${usable(r)&&!r.complete?'已覆盖':'覆盖'} ${esc(r.eligible)}/${esc(r.total)} 只`;
    const entries=(label,rows,tone)=>`<div class="etf-broad-column ${tone}"><h5>${label}<span>${rows.length} 个指数</span></h5>${rows.length
      ?`<ul class="etf-broad-list">${rows.map(r=>`<li><span class="etf-broad-name">${esc(r.name)}</span><span class="etf-broad-number">${amountText(r.net_subscription)}</span><small class="etf-broad-coverage">${coverage(r)}</small></li>`).join('')}</ul>`
      :'<p class="etf-broad-empty">暂无可用记录</p>'}</div>`;
    const neutral=(label,rows)=>rows.length?`<div><b>${label}：</b>${rows.map(r=>`${esc(r.name)}（${coverage(r)}）`).join('、')}</div>`:'';
    const totalsStatus=t=>!t?.covered_indexes?'暂无可用金额':t.complete?'名单内估算':'已覆盖估算';
    const totals=(t)=>`<dl class="etf-broad-kpis"><div class="etf-broad-up"><dt>总净申购</dt><dd>${amountText(t?.subscription)}</dd></div><div class="etf-broad-down"><dt>总净赎回</dt><dd>${amountText(t?.redemption)}</dd></div></dl>`;
    const valid=broad.rows.filter(usable);
    const columns=entries('净申购',valid.filter(r=>r.net_subscription>0).sort((a,b)=>b.net_subscription-a.net_subscription),'etf-broad-up')
      +entries('净赎回',valid.filter(r=>r.net_subscription<0).sort((a,b)=>a.net_subscription-b.net_subscription),'etf-broad-down');
    const other=neutral('无净变化',valid.filter(r=>r.net_subscription===0))+neutral('暂无可用金额',broad.rows.filter(r=>!usable(r)));
    const t=broad.totals;
    const interval=`<div class="etf-broad-totals"><div class="etf-broad-bar"><h5>当前区间合计</h5><span class="etf-broad-badge">${totalsStatus(t)}${t?` · ${esc(t.covered_indexes)}/${esc(t.total_indexes)} 个指数`:''}</span></div>${totals(t)}</div>`;
    const week=broad.weekly;
    let weekly='';
    if(week&&week.start_date!==localWeek()){
      weekly=`<div id="etfBroadWeekly" class="etf-broad-week">${weekPlaceholder('正在读取本周本机记录…')}</div>`;
    }else if(week){
      const dates=week.dates||[],dateText=dates.length?`${esc(week.start_date)} 至 ${esc(dates.at(-1))}`:esc(week.start_date);
      const dayNotes=(label,days)=>days?.length?`<p>${label}：${days.map(d=>esc(d)).join('、')}</p>`:'';
      const notes=dayNotes('暂无数据',week.missing_dates)+dayNotes('部分覆盖',week.partial_dates);
      const summary=week.calendar_confirmed===false?'交易日历尚未确认':dates.length?`${esc(week.covered_days)}/${dates.length} 日有数据 · ${totalsStatus(week.totals)}`:'本周暂无已收盘交易日';
      weekly=`<div id="etfBroadWeekly" class="etf-broad-week"><div class="etf-broad-bar"><h5>本周小结</h5><span class="etf-broad-date">${dateText}</span></div><p class="etf-broad-week-status">${summary}</p>${dates.length?totals(week.totals):''}${notes?`<div class="etf-broad-gaps">${notes}</div>`:''}</div>`;
    }
    const scopeNote=broad.confirmed_markets?.length===2?'':'未核验交易所名单的市场按已映射产品计覆盖，可能包含待上市基金。';
    return `<section id="etfBroadSummary" class="etf-broad-card" aria-labelledby="etfBroadTitle"><div class="etf-broad-bar"><h4 id="etfBroadTitle">宽指ETF净申购／净赎回（${data.days===1?'日':'近5个交易日'}）</h4><span class="etf-broad-badge">沪深合并 · 估算</span></div><div class="etf-broad-grid">${columns}</div>${other?`<div class="etf-broad-other">${other}</div>`:''}${interval}${weekly}<details class="etf-broad-method"><summary>计算口径与数据来源</summary><p>按沪深被动ETF的标的指数合并；挂钩名单核对日 ${esc(broad.mapping_date)}。覆盖不足只计算已覆盖基金，缺失或需复核不按零处理。${scopeNote}</p><p>当前区间按各指数净额的正、负分别加总。本周按自然周累计各指数逐日净额，再按正、负加总，不等于滚动近5日。</p></details></section>`;
  }
  function render(data) {
    shownWeek=data.broad_index_summary?.weekly?.start_date||null;
    $('etfFlowSourceInfo').textContent=`净值来源：${data.source_label||source()}；${data.source_note||'份额仍取交易所，仅切换同日期单位净值。'} 当前榜单缓存净值：${(data.nav_sources||[]).join('／')||'尚无'}。`;
    const ranks=(rows,title)=>`<div class="capital-flow-rank-card"><h4>${title}</h4><div class="capital-flow-table capital-flow-table-scroll etf-rank-table"><table><thead><tr><th>排名</th><th>证券代码／基金简称</th><th>份额变化（亿份）</th><th>成交额</th><th>估算净流入额</th></tr></thead><tbody>${rows.length?rows.map((row,i)=>`<tr><td>${i+1}</td><td><b>${esc(row.name)}</b><small>${esc(row.code)}</small></td><td>${share(row.share_change)}</td><td>${amount(row.amount)}</td><td>${flowAmount(row.net_inflow)}</td></tr>`).join(''):'<tr><td colspan="5" class="muted">暂无有效记录；数据不足不等于没有资金流入／流出。</td></tr>'}</tbody></table></div></div>`;
    $('etfFlowResults').innerHTML=`<p><b>数据截至 ${esc(data.cutoff)}</b> · ${data.days===1?'日':'近5个交易日'} · ${esc(data.dates?.[0]||'—')} 至 ${esc(data.cutoff)}</p><p class="muted">${esc(data.method)}</p><p class="${data.complete?'muted':'notice'}">${data.complete?'当前名单区间覆盖完整':'区间尚未完整，以下仅为已完成数据的样本排名'}：沪市 ${data.markets.SH.complete}/${data.markets.SH.total}，深市 ${data.markets.SZ.complete}/${data.markets.SZ.total}；缺失 ${data.missing_count}，分红／拆分等需复核 ${data.event_excluded}。${data.stale?'正在显示旧记录，不是最新交易日数据。':''}</p><p class="muted">${esc(data.note)} 成交额缺失显示“缺失”，不影响已有净申购估算记录的保存。</p>${broadIndexSummary(data)}<div class="capital-flow-rank-grid">${ranks(data.inflow,'估算净流入榜')}${ranks(data.outflow,'估算净流出榜')}</div>${screening(data)}`;
  }
  async function load() {
    const {windowDays,minDays}=rule(),token=++generation;
    const data=await api(`/api/etf-flow?days=${Number($('etfFlowDays').value)}&limit=${Number($('etfFlowLimit').value)}&window_days=${windowDays}&min_inflow_days=${minDays}&source=${source()}`);
    if(token===generation)render(data);
  }
  function refreshLocalWeek(force=false) {
    const changed=shownWeek!==localWeek();
    const weekly=$('etfBroadWeekly');
    if(changed&&weekly)weekly.innerHTML=weekPlaceholder('正在读取本周本机记录…');
    if((!changed&&!force)||busy||document.visibilityState==='hidden'||document.body.dataset.view!=='flow')return;
    void load().catch(()=>{
      const current=$('etfBroadWeekly');
      if(shownWeek!==localWeek()&&current)current.innerHTML=weekPlaceholder('暂时读不到本周记录，请重新进入资金流向。');
    });
  }
  if(typeof document!=='undefined'){
    const scheduleWeekBoundary=()=>{
      const delay=mondayStamp()+weekMs-chinaOffset-Date.now()+100;
      setTimeout(()=>{refreshLocalWeek();scheduleWeekBoundary();},Math.max(delay,100));
    };
    document.addEventListener('gupiao:viewchange',event=>{if(event.detail==='flow')refreshLocalWeek(true);});
    document.addEventListener('visibilitychange',()=>{if(document.visibilityState!=='hidden')refreshLocalWeek();});
    window.addEventListener('focus',()=>refreshLocalWeek());
    scheduleWeekBoundary();
  }
  async function poll(job) {
    busy=true;$('etfFlowRefresh').disabled=true;
    if(job?.source)$('etfFlowSource').value=job.source;
    $('etfFlowSource').disabled=true;
    $('etfFlowWindowDays').disabled=true;$('etfFlowMinInflowDays').disabled=true;
    try {
      while(job?.status==='running') {
        $('etfFlowStatus').textContent=`${job.message}；按${job.window_days||10}个交易日补缺；进度 ${job.attempted}/${job.total}，成功处理 ${job.succeeded}，异常 ${job.failed}`;
        await load();
        await new Promise(resolve=>setTimeout(resolve,1500));
        job=(await api('/api/etf-flow/status')).job;
      }
      $('etfFlowStatus').textContent=job?.message||'已恢复本机ETF记录。';
      await load();
    } finally {busy=false;$('etfFlowRefresh').disabled=false;$('etfFlowWindowDays').disabled=false;$('etfFlowMinInflowDays').disabled=false;$('etfFlowSource').disabled=false;}
  }
  $('etfFlowRefresh').onclick=async()=>{
    if(busy)return;
    busy=true;$('etfFlowRefresh').disabled=true;
    try {const {windowDays}=rule();await poll((await api(`/api/etf-flow/refresh?window_days=${windowDays}&source=${source()}`,{method:'POST'})).job);}
    catch(error){$('etfFlowStatus').textContent=`更新未完成，已显示及已保存记录保留：${error.message}`;}
    finally {busy=false;$('etfFlowRefresh').disabled=false;}
  };
  $('etfFlowSource').onchange=()=>{
    try{localStorage.setItem('gupiao.etfNavSource',source());}catch{}
    void load().then(()=>{$('etfFlowStatus').textContent='已切换本机净值记录；若数据不足，请点“更新沪深ETF数据／继续补缺”。切换本身不联网。';}).catch(error=>{$('etfFlowStatus').textContent=error.message;});
  };
  for(const id of ['etfFlowDays','etfFlowLimit']) $(id).onchange=()=>void load().catch(error=>{$('etfFlowStatus').textContent=error.message;});
  for(const id of ['etfFlowWindowDays','etfFlowMinInflowDays']) $(id).onchange=()=>{
    const n=Number($('etfFlowWindowDays').value);
    if(Number.isInteger(n)&&n>=1&&n<=60){$('etfFlowMinInflowDays').max=n;if(Number($('etfFlowMinInflowDays').value)>n)$('etfFlowMinInflowDays').value=n;}
    void load().catch(error=>{$('etfFlowStatus').textContent=error.message;});
  };
  void (async()=>{try {await load();const job=(await api('/api/etf-flow/status')).job;if(job?.status==='running'){if(job.window_days){$('etfFlowWindowDays').value=job.window_days;$('etfFlowMinInflowDays').max=job.window_days;if(Number($('etfFlowMinInflowDays').value)>job.window_days)$('etfFlowMinInflowDays').value=job.window_days;}await poll(job);}}catch(error){$('etfFlowStatus').textContent=`本地ETF记录恢复失败：${error.message}`;}})();
})();
