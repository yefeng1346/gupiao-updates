/* Pure local SVG renderer. Positive = net long; this is not a price forecast. */
((root,factory)=>{
  const value=factory();
  if(typeof module==='object'&&module.exports)module.exports=value;
  else root.FuturesHistory=value;
})(globalThis,()=>{
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const groups={focus:'重点会员',others:'其他所选会员',combined:'两组合计'};
  const products={total:'四品种合计',IM:'中证1000（IM）',IC:'中证500（IC）',IF:'沪深300（IF）',IH:'上证50（IH）'};
  const normalize=(group,product)=>({group:Object.hasOwn(groups,group)?group:'focus',product:Object.hasOwn(products,product)?product:'total'});
  const number=value=>`${value>0?'+':''}${value.toLocaleString('zh-CN')}`;
  function render(data,group='focus',product='total'){
    ({group,product}=normalize(group,product));
    const points=(data?.series?.[group]?.[product]||[]).slice(-60);
    const valid=point=>typeof point.value==='number'&&Number.isFinite(point.value);
    const known=points.filter(valid),note='真实历史净持仓：正数净多、负数净空；不是价格走势或预测图。';
    const list=`<details><summary>历史数据点与缺失原因</summary><ul class="futures-missing-list">${points.map(p=>`<li>${esc(p.trade_date)}：${valid(p)?`${esc(number(p.value))}手`:'缺失，不补零'}${p.reason?`；${esc(p.reason)}`:''}</li>`).join('')}</ul></details>`;
    if(!known.length)return `<p class="notice">尚无该范围内的完整历史点；请保留后续收盘记录，缺失不会补零。</p><p class="muted">${note}</p>${list}`;
    const left=90,top=18,width=780,height=220,scale=Math.max(...known.map(p=>Math.abs(p.value)))||1;
    const x=index=>left+(points.length>1?index/(points.length-1):.5)*width;
    const y=value=>top+(1-value/scale*.9)*height/2;
    const coord=value=>value.toFixed(2);
    const runs=[];let run=[];
    const flush=()=>{if(run.length>1)runs.push(run);run=[];};
    for(let i=0;i<points.length;i++){
      const p=points[i];if(!valid(p)){flush();continue;}
      if(p.break_before)flush();run.push([x(i),y(p.value)]);
    }
    flush();
    const paths=runs.map(run=>`<path class="futures-history-line" d="${run.map(([x,y],i)=>`${i?'L':'M'}${coord(x)},${coord(y)}`).join(' ')}" fill="none" stroke="var(--accent)" stroke-width="2.5"/>`).join('');
    const dots=points.map((p,i)=>valid(p)?`<circle class="futures-history-point" data-date="${esc(p.trade_date)}" data-value="${p.value}" cx="${coord(x(i))}" cy="${coord(y(p.value))}" r="4" fill="var(--accent)" tabindex="0"><title>${esc(p.trade_date)}：净持仓${esc(number(p.value))}手${p.reason?`；${esc(p.reason)}`:''}</title></circle>`:'').join('');
    const ticks=[...new Set(Array.from({length:Math.min(6,points.length)},(_,i)=>Math.round(i*(points.length-1)/Math.max(1,Math.min(6,points.length)-1))))];
    const dates=ticks.map(i=>`<text x="${coord(x(i))}" y="270" text-anchor="middle" fill="var(--muted)">${esc(points[i].trade_date)}</text>`).join('');
    const labels=[scale,0,-scale].map(v=>`<text x="80" y="${coord(y(v)+4)}" text-anchor="end" fill="var(--muted)">${esc(number(v))}</text>`).join('');
    return `<p class="muted">${known.length}个有效点／${points.length}个交易日；${known.length===1?'只有1个有效点，不能形成连线。':'缺失或合约范围变化处断开，不插值。'}${note}</p><svg class="futures-history-svg" viewBox="0 0 900 292" role="img" aria-label="${esc(groups[group]+' '+products[product]+' 真实历史净持仓，单位手')}"><title>真实历史净持仓</title><desc>${esc(note)}</desc><line x1="90" y1="${coord(y(0))}" x2="870" y2="${coord(y(0))}" stroke="var(--line-strong)" stroke-dasharray="5 4"/>${labels}${dates}${paths}${dots}</svg>${list}`;
  }
  function panel(data,selection={}){
    const {group,product}=normalize(selection.group,selection.product);
    const options=(items,selected)=>Object.entries(items).map(([value,label])=>`<option value="${value}"${value===selected?' selected':''}>${label}</option>`).join('');
    return `<section id="futuresHistorySection"><h3>真实历史净持仓曲线</h3><p class="muted">${esc(data.note)} 当前其他组：${esc((data.other_members||[]).join('、')||'无')}。</p><div class="capital-flow-controls"><label>观察范围<select id="futuresHistoryGroup">${options(groups,group)}</select></label><label>期指品种<select id="futuresHistoryProduct">${options(products,product)}</select></label></div><div id="futuresHistoryPlot">${render(data,group,product)}</div></section>`;
  }
  return Object.freeze({render,panel});
});
