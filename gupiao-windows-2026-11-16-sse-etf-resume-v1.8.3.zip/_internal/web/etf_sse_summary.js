/* Text only; restore/source changes read local cache, explicit refresh fetches. */
(()=>{
  const sourceInput=$('sseSummarySource'),button=$('sseSummaryRefresh'),status=$('sseSummaryStatus'),results=$('sseSummaryResults');
  if(!sourceInput||!button||!status||!results)return;
  let sourceTouched=false,hasSavedSource=false;
  try{const saved=localStorage.getItem('gupiao.sseSummarySource');if(['auto','eastmoney','sina'].includes(saved)){sourceInput.value=saved;hasSavedSource=true;}}catch{}
  let busy=false,generation=0;
  const source=()=>['auto','eastmoney','sina'].includes(sourceInput.value)?sourceInput.value:'auto';
  const text=v=>esc(String(v??''));
  const money=value=>{
    if(typeof value!=='number'||!Number.isFinite(value))return '暂不可计算';
    const size=Math.abs(value)/1e8,label=value<0?'净赎回':value>0?'净申购':'无净变化';
    return label+(size>0&&size<.005?'不足0.01亿元':`${size.toFixed(2)}亿元`);
  };
  function progressText(p,includeNew=false){
    if(!p)return '';
    return `份额／名单已核验${text(p.share_completed)}/${text(p.share_total)}日；净值记录已完成${text(p.nav_completed)}/${text(p.nav_total)}条，剩余${text(p.nav_remaining)}条${includeNew?`，本轮新增${text(p.new_nav||0)}条`:''}。位置已保存，可重启后继续补缺。${p.scope_complete===false?'总量按已取得名单计算，名单补齐后会调整。':''}`;
  }
  function render(data){
    const progressHtml=data.download_progress?`<p id="sseDownloadProgress" class="muted">${progressText(data.download_progress)}此处按ETF×日期计数，与完整交易日数不同。</p>`:'';
    results.innerHTML=`<h3>上交所ETF近20个交易日净申赎额（估算）</h3><p>统计区间 ${text(data.start_date)} 至 ${text(data.cutoff)}；基准日 ${text(data.baseline_date)}；净值来源 ${text(data.source_label)}。${data.stale?'当前为旧记录，不是最新目标交易日数据。':''}</p>${progressHtml}<p class="${data.complete?'muted':'notice'}">完整 ${text(data.complete_days)}/20个交易日；${data.complete?`区间合计：${money(data.net_subscription)}`:'区间合计暂不可计算，不把已完成的部分相加冒充20日全市场数据'}。已完整日期中：净申购${text(data.positive_days)}日、净赎回${text(data.negative_days)}日、无净变化${text(data.zero_days)}日。</p><details><summary>逐日文字统计（点击查看）</summary><ul style="max-height:280px;overflow:auto">${(data.daily||[]).map(r=>`<li>${text(r.trade_date)}：${r.complete?money(r.net_subscription):'暂不可计算'}；覆盖${text(r.eligible)}/${text(r.total)}只${r.reason?`；${text(r.reason)}`:''}。</li>`).join('')}</ul></details><details><summary>计算口径与数据说明</summary><p class="muted">${text(data.method)} ${text(data.note)}</p></details>`;
  }
  async function load(){
    const token=++generation,s=source();const data=await api(`/api/etf-sse-summary?source=${s}`);
    if(token===generation&&s===source())render(data);
  }
  function setBusy(value){busy=value;button.disabled=value;sourceInput.disabled=value;}
  async function poll(job){
    if(!job)throw Error('更新状态缺失，已有数据保留');
    if(job.source){sourceInput.value=job.source;try{localStorage.setItem('gupiao.sseSummarySource',source());}catch{}}
    while(job.status==='running'){
      status.textContent=`${job.message}；${progressText(job.progress,true)} 本轮处理${job.attempted}项，成功${job.succeeded}，异常${job.failed}`;
      await load();await new Promise(r=>setTimeout(r,1500));job=(await api('/api/etf-sse-summary/status')).job;
      if(!job)throw Error('更新状态缺失，已有数据保留');
    }
    await load();status.textContent=job.message||'已读取本机记录。';
  }
  button.onclick=async()=>{
    if(busy)return;++generation;setBusy(true);
    try{await poll((await api(`/api/etf-sse-summary/refresh?source=${source()}`,{method:'POST'})).job);}
    catch(error){status.textContent=`更新未完成，原结果及记录保留：${error.message}`;}
    finally{setBusy(false);}
  };
  sourceInput.onchange=()=>{if(busy)return;sourceTouched=true;try{localStorage.setItem('gupiao.sseSummarySource',source());}catch{}void load().then(()=>status.textContent='已切换本机净值记录；数据不足可点击继续补缺，切换本身不联网。').catch(error=>status.textContent=error.message);};
  void(async()=>{
    try{await load();if(busy)return;const token=generation,response=await api('/api/etf-sse-summary/status'),job=response.job;
      if(token!==generation||busy)return;
      if(job?.status!=='running'){
        if(!sourceTouched&&!hasSavedSource&&['auto','eastmoney','sina'].includes(response.resume_source)&&source()!==response.resume_source){sourceInput.value=response.resume_source;await load();}
        return;
      }
      setBusy(true);try{await poll(job);}finally{setBusy(false);}
    }catch(error){if(!busy)status.textContent=`本机统计恢复未完成，原结果保留：${error.message}`;}
  })();
})();
