/* Local cache on open; network refresh only after the user's explicit click. */
(() => {
  let busy=false;
  const share=value=>value==null?'缺失':`${value>=0?'+':''}${(value/1e8).toFixed(2)}`;
  const amount=value=>value==null?'缺失':flowAmount(value);
  function render(data) {
    const ranks=(rows,title)=>`<div class="capital-flow-rank-card"><h4>${title}</h4><div class="capital-flow-table capital-flow-table-scroll etf-rank-table"><table><thead><tr><th>排名</th><th>证券代码／基金简称</th><th>份额变化（亿份）</th><th>成交额</th><th>估算净流入额</th></tr></thead><tbody>${rows.length?rows.map((row,i)=>`<tr><td>${i+1}</td><td><b>${esc(row.name)}</b><small>${esc(row.code)}</small></td><td>${share(row.share_change)}</td><td>${amount(row.amount)}</td><td>${flowAmount(row.net_inflow)}</td></tr>`).join(''):'<tr><td colspan="5" class="muted">暂无有效记录；数据不足不等于没有资金流入／流出。</td></tr>'}</tbody></table></div></div>`;
    $('etfFlowResults').innerHTML=`<p><b>数据截至 ${esc(data.cutoff)}</b> · ${data.days===1?'日':'近5个交易日'} · ${esc(data.dates?.[0]||'—')} 至 ${esc(data.cutoff)}</p><p class="muted">${esc(data.method)}</p><p class="${data.complete?'muted':'notice'}">${data.complete?'当前名单区间覆盖完整':'区间尚未完整，以下仅为已完成数据的样本排名'}：沪市 ${data.markets.SH.complete}/${data.markets.SH.total}，深市 ${data.markets.SZ.complete}/${data.markets.SZ.total}；缺失 ${data.missing_count}，分红／拆分等需复核 ${data.event_excluded}。${data.stale?'正在显示旧记录，不是最新交易日数据。':''}</p><p class="muted">${esc(data.note)} 成交额缺失显示“缺失”，不影响已有净申购估算记录的保存。</p><div class="capital-flow-rank-grid">${ranks(data.inflow,'估算净流入榜')}${ranks(data.outflow,'估算净流出榜')}</div>`;
  }
  async function load() {
    const data=await api(`/api/etf-flow?days=${Number($('etfFlowDays').value)}&limit=${Number($('etfFlowLimit').value)}`);
    render(data);
  }
  async function poll(job) {
    busy=true;$('etfFlowRefresh').disabled=true;
    try {
      while(job?.status==='running') {
        $('etfFlowStatus').textContent=`${job.message}；进度 ${job.attempted}/${job.total}，成功处理 ${job.succeeded}，异常 ${job.failed}`;
        await load();
        await new Promise(resolve=>setTimeout(resolve,1500));
        job=(await api('/api/etf-flow/status')).job;
      }
      $('etfFlowStatus').textContent=job?.message||'已恢复本机ETF记录。';
      await load();
    } finally {busy=false;$('etfFlowRefresh').disabled=false;}
  }
  $('etfFlowRefresh').onclick=async()=>{
    if(busy)return;
    busy=true;$('etfFlowRefresh').disabled=true;
    try {await poll((await api('/api/etf-flow/refresh',{method:'POST'})).job);}
    catch(error){$('etfFlowStatus').textContent=`更新未完成，已显示及已保存记录保留：${error.message}`;}
    finally {busy=false;$('etfFlowRefresh').disabled=false;}
  };
  for(const id of ['etfFlowDays','etfFlowLimit']) $(id).onchange=()=>void load().catch(error=>{$('etfFlowStatus').textContent=error.message;});
  void (async()=>{try {await load();const job=(await api('/api/etf-flow/status')).job;if(job?.status==='running')await poll(job);}catch(error){$('etfFlowStatus').textContent=`本地ETF记录恢复失败：${error.message}`;}})();
})();
